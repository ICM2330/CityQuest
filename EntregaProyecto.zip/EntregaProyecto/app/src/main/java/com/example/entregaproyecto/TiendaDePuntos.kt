package com.example.entregaproyecto

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class TiendaDePuntos : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tienda_de_puntos)
    }
}